#ifndef SFMT_JUMP_PARAMS_INCLUDED
#define SFMT_JUMP_PARAMS_INCLUDED

#if SFMT_MEXP == 607
  #include "characteristic.607.h"
#elif SFMT_MEXP == 1279
  #include "characteristic.1279.h"
#elif SFMT_MEXP == 2281
  #include "characteristic.2281.h"
#elif SFMT_MEXP == 4253
  #include "characteristic.4253.h"
#elif SFMT_MEXP == 11213
  #include "characteristic.11213.h"
#elif SFMT_MEXP == 19937
  #include "characteristic.19937.h"
#elif SFMT_MEXP == 44497
  #include "characteristic.44497.h"
#elif SFMT_MEXP == 86243
  #include "characteristic.86243.h"
#elif SFMT_MEXP == 132049
  #include "characteristic.132049.h"
#elif SFMT_MEXP == 216091
  #include "characteristic.216091.h"
#else
  #if defined(__GNUC__) && !defined(__ICC)
    #error "SFMT_MEXP is not valid."
    #undef SFMT_MEXP
  #else
    #undef SFMT_MEXP
  #endif
#endif

#endif /* SFMT_JUMP_PARAMS_INCLUDED */
